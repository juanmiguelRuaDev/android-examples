/** Automatically generated file. DO NOT MODIFY */
package com.tema2_servicios;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}