/** Automatically generated file. DO NOT MODIFY */
package com.tema11_dibujo1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}